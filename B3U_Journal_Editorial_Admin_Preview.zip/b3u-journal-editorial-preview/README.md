# B3U Journal Editorial Preview

This is a self-contained individual journal-entry preview intended for an admin iframe or a direct component conversion.

## Open locally

Keep `index.html` and `B3U3D.png` in the same folder, then open `index.html` in a browser.

## Update the live preview

The page exposes a small integration API:

```js
previewFrame.contentWindow.setB3UArticlePreview({
  status: "Draft",
  category: "Taking Your Power Back",
  title: "The Moment You Stop Asking Permission to Become",
  dek: "A short article introduction.",
  author: "Dr. Bree Charles",
  date: "July 6, 2026",
  readTime: "6 min read",
  heroImage: "https://example.com/article-image.jpg",
  heroAlt: "Dr. Bree Charles speaking to an audience",
  opening: "Opening paragraph copy...",
  burnTitle: "Release the story that keeps you small.",
  burnBody: "Burn section copy...",
  breakTitle: "Interrupt the pattern with one honest choice.",
  breakBody: "Break section copy...",
  becomeTitle: "Take the next brave step.",
  becomeBody: "Become section copy...",
  quote: "You do not have to stay where life left you.",
  reflectionQuestion: "What are you ready to stop carrying?",
  ctaLabel: "Join The Take Back Weekly",
  ctaUrl: "/subscribe"
});
```

For cross-frame updates, send a message to the iframe:

```js
previewFrame.contentWindow.postMessage({
  type: "B3U_ARTICLE_PREVIEW_UPDATE",
  payload: articleDraft
}, window.location.origin);
```

In production, validate `event.origin` against the admin application's origin before accepting cross-frame messages.

## Included behaviors

- Desktop, tablet, and mobile preview controls
- Editorial article hero and responsive reading column
- Burn / Break / Become article sections
- Copy-link, Facebook, and LinkedIn share actions
- Reading-progress indicator
- Reflection and newsletter conversion block
- Podcast cross-promotion, author card, and related entries
- Reduced-motion and keyboard-focus accommodations
